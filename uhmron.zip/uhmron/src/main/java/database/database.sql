DROP DATABASE IF EXISTS MotorSpace;
CREATE DATABASE MotorSpace;
USE MotorSpace;

CREATE TABLE UtenteRegistrato (
                                  username VARCHAR(30) PRIMARY KEY,
                                  email VARCHAR(50) NOT NULL,
                                  password VARCHAR(30) NOT NULL,
                                  nome VARCHAR(30) NOT NULL,
                                  cognome VARCHAR(30) NOT NULL,
                                  datadinascita DATE NOT NULL
);

CREATE TABLE Amministratore (
                                username VARCHAR(30) PRIMARY KEY,
                                tipoamministratore VARCHAR(30) NOT NULL,
                                FOREIGN KEY (username) REFERENCES UtenteRegistrato (username)
);

CREATE TABLE Cliente (
                         username VARCHAR(30) PRIMARY KEY,
                         FOREIGN KEY (username) REFERENCES UtenteRegistrato (username)
);

CREATE TABLE Categoria (
                           id INT PRIMARY KEY,
                           nome VARCHAR(30) NOT NULL,
                           descrizione VARCHAR(150)
);

CREATE TABLE Prodotto (
                          nome VARCHAR(30) NOT NULL,
                          descrizione VARCHAR(50) NOT NULL,
                          codice VARCHAR(30) PRIMARY KEY,
                          marca VARCHAR(30) NOT NULL,
                          prezzo FLOAT NOT NULL,
                          categoria INT,
                          FOREIGN KEY (categoria) REFERENCES Categoria (id),
                          FULLTEXT KEY (nome,descrizione)
);



CREATE TABLE Recensione (
                            autore VARCHAR(30) NOT NULL,
                            prodotto VARCHAR(30) NOT NULL,
                            testo VARCHAR(200) NOT NULL,
                            data DATE NOT NULL,
                            FOREIGN KEY (autore) REFERENCES Cliente (username),
                            FOREIGN KEY (prodotto) REFERENCES Prodotto (codice),
                            PRIMARY KEY(autore, prodotto)
);

CREATE TABLE InCarrello (
                            username VARCHAR(30) NOT NULL,
                            qt INT NOT NULL,
                            prezzounitario FLOAT NOT NULL,
                            prodotto VARCHAR(30) NOT NULL,
                            FOREIGN KEY (username) REFERENCES Cliente (username),
                            FOREIGN KEY (prodotto) REFERENCES Prodotto (codice),
                            PRIMARY KEY(username, prodotto)
);

CREATE TABLE Ordine (
                        id_ordine VARCHAR(30) PRIMARY KEY,
                        cliente VARCHAR(30) NOT NULL,
                        dataordine DATE NOT NULL,
                        dataspedizione DATE NOT NULL,
                        dataconsegna DATE NOT NULL,
                        FOREIGN KEY (cliente) REFERENCES Cliente (username)
);

CREATE TABLE IndirizzoSpedizione (
                                     ordine VARCHAR(30) PRIMARY KEY,
                                     via VARCHAR(30) NOT NULL,
                                     cap VARCHAR(5) NOT NULL,
                                     città VARCHAR(30) NOT NULL,
                                     regione VARCHAR(30) NOT NULL,
                                     FOREIGN KEY (ordine) REFERENCES Ordine (id_ordine)
);

CREATE TABLE Pagamento (
                           ordine VARCHAR(30) PRIMARY KEY,
                           datapagamento VARCHAR(30) NOT NULL,
                           tipodicarta VARCHAR(10) NOT NULL,
                           numerodicartaparziale VARCHAR(8) NOT NULL,
                           FOREIGN KEY (ordine) REFERENCES Ordine (id_ordine)
);

CREATE TABLE LineaDOrdine (
                              ordine VARCHAR(30) NOT NULL,
                              prodotto VARCHAR(30) NOT NULL,
                              qt INT NOT NULL,
                              prezzounitario FLOAT NOT NULL,
                              FOREIGN KEY (ordine) REFERENCES Ordine (id_ordine),
                              FOREIGN KEY (prodotto) REFERENCES Prodotto (codice),
                              PRIMARY KEY(ordine, prodotto)
);

CREATE TABLE ProdottoInCatalogo (
                                    prodotto VARCHAR(30) PRIMARY KEY,
                                    acquistabile BOOLEAN NOT NULL,
                                    prezzo FLOAT NOT NULL,
                                    FOREIGN KEY (prodotto) REFERENCES Prodotto(codice)
);

CREATE TABLE Sconto (
                        codicesconto VARCHAR(30) PRIMARY KEY,
                        prodotto VARCHAR(30) NOT NULL,
                        valore INT NOT NULL,
                        FOREIGN KEY (prodotto) REFERENCES Prodotto(codice)
);