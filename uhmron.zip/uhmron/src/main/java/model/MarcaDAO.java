package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MarcaDAO {
    public List<Marca> doRetrieveAll(){
        try(Connection con = ConPool.getConnection()) {
            PreparedStatement ps= con.prepareStatement("SELECT id, nome FROM marca");
            ArrayList<Marca> marchi= new ArrayList<Marca>();
            ResultSet rs= ps.executeQuery();
            while(rs.next()){
                Marca m= new Marca();
                m.setId(rs.getInt(1));
                m.setNome(rs.getString(2));
                marchi.add(m);
            }
            return marchi;
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
    }
}
