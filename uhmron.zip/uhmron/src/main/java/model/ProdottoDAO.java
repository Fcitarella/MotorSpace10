package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdottoDAO {
    public List<Prodotto>doRetrieveAll(int offset,int limit) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT prodotto.nome,prodotto.descrizione,prodotto.codice,prodotto.marca,prodotto.prezzo FROM prodotto limit ?,?");
            ps.setInt(1, offset);
            ps.setInt(2, limit);
            ResultSet rs = ps.executeQuery();

            ArrayList<Prodotto> prodotti = new ArrayList<>();
            while (rs.next()) {
                Prodotto P = new Prodotto();
                P.setNome(rs.getString(1));
                P.setDescrizione(rs.getString(2));
                P.setId(rs.getInt(3));
                P.setMarca((rs.getString(4)));
                P.setPrezzo(rs.getFloat(5));
                prodotti.add(P);
            }
            return prodotti;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public Prodotto doRetrieveById(String id){
        try(Connection con =ConPool.getConnection()){
            PreparedStatement ps=con.prepareStatement("SELECT prodotto.nome,prodotto.descrizione,prodotto.codice,prodotto.marca,prodotto.prezzo FROM prodotto WHERE codice=?");
            ps.setString(1,id);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                Prodotto P=new Prodotto();
                P.setNome(rs.getString(1));
                P.setDescrizione(rs.getString(2));
                P.setId(rs.getInt(3));
                P.setMarca((rs.getString(4)));
                P.setPrezzo(rs.getFloat(5));
                return P;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Prodotto> doRetrieveByNomeOrDescrizione(String against,int offset,int limit) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT prodotto.nome,prodotto.descrizione,prodotto.codice,prodotto.marca,prodotto.prezzo FROM prodotto WHERE MATCH (nome,descrizione)AGAINST(?) LIMIT ?,?");
            ps.setString(1, against);
            ps.setInt(2, offset);
            ps.setInt(3, limit);
            ArrayList<Prodotto> prodotti = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Prodotto P=new Prodotto();
                P.setNome(rs.getString(1));
                P.setDescrizione(rs.getString(2));
                P.setId(rs.getInt(3));
                P.setMarca((rs.getString(4)));
                P.setPrezzo(rs.getFloat(5));
                prodotti.add(P);
            }
            return prodotti;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Prodotto> doRetrieveByCategoria(int categoria, int offset, int limit) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT prodotto.nome,prodotto.descrizione,prodotto.codice,prodotto.marca,prodotto.prezzo FROM prodotto JOIN categoria ON prodotto.codice=categoria.id WHERE categoria.id=? LIMIT ?,?");
            ps.setInt(1, categoria);
            ps.setInt(2, offset);
            ps.setInt(3, limit);
            ArrayList<Prodotto> prodotti = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto P = new Prodotto();
                P.setNome(rs.getString(1));
                P.setDescrizione(rs.getString(2));
                P.setId(rs.getInt(3));
                P.setMarca((rs.getString(4)));
                P.setPrezzo(rs.getFloat(5));
                prodotti.add(P);
            }
            return prodotti;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public List<Prodotto> doRetrieveByMarca(int marca, int offset, int limit) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT prodotto.nome,prodotto.descrizione,prodotto.codice,prodotto.marca,prodotto.prezzo FROM prodotto LEFT JOIN prodotto marca ON id-idprodotto WHERE idmarca=? LIMIT ?,?");
            ps.setInt(1, marca);
            ps.setInt(2, offset);
            ps.setInt(3, limit);
            ArrayList<Prodotto> prodotti = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto P = new Prodotto();
                P.setNome(rs.getString(1));
                P.setDescrizione(rs.getString(2));
                P.setId(rs.getInt(3));
                P.setMarca((rs.getString(4)));
                P.setPrezzo(rs.getFloat(5));
                prodotti.add(P);
            }
            return prodotti;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
        private static List<Marca> getMarca(Connection con,int idProdotto)throws SQLException{
        PreparedStatement ps= con.prepareStatement(" SELECT idc,nome FROM marca LEFT JOIN prodotto_marca WHERE id=?");
        ps.setInt(1,idProdotto);
        ArrayList<Marca> Marchi= new ArrayList<>();
        ResultSet rs= ps.executeQuery();
        while(rs.next()){
            Marca m= new Marca();
            m.setId(rs.getInt(1));
            m.setNome(rs.getString(2));
            Marchi.add(m);
                }
        return Marchi;
        }

    private static List<Categoria> getCategoria(Connection con,int idProdotto)throws SQLException {
        PreparedStatement ps = con.prepareStatement(" SELECT idcategoria,nome FROM categoria LEFT JOIN prodotto_categoria WHERE id=?");
        ps.setInt(1, idProdotto);
        ArrayList<Categoria> categoria = new ArrayList<>();
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Categoria C = new Categoria();
            C.setId(rs.getInt(1));
            C.setNome(rs.getString(2));
            categoria.add(C);
        }
        return categoria;
    }

    }
