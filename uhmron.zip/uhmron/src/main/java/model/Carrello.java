package model;

import java.util.Collection;
import java.util.LinkedHashMap;

public class Carrello {
    public static class ProdottoQuantità {
        private Prodotto prodotto;
        private int quantità;

        private ProdottoQuantità(Prodotto prodotto, int quantità) {
            this.prodotto = prodotto;
            this.quantità = quantità;
        }

        public Prodotto getProdotto() {
            return prodotto;
        }

        public void setProdotto(Prodotto prodotto) {
            this.prodotto = prodotto;
        }

        public int getQuantità() {
            return quantità;
        }

        public void setQuantità(int quantità) {
            this.quantità = quantità;
        }
    }

    private LinkedHashMap<Integer, ProdottoQuantità> prodotti = new LinkedHashMap<>();

    public Collection<ProdottoQuantità> getProdotti() {

        return prodotti.values();
    }

    public ProdottoQuantità get(int prodId) {
        return prodotti.get(prodId);
    }

    public void put(Prodotto prodotto, int quantità) {
        prodotti.put(prodotto.getId(), new ProdottoQuantità(prodotto, quantità));
    }
    public ProdottoQuantità remove(int prodId){
        return prodotti.remove(prodId);
    }
}